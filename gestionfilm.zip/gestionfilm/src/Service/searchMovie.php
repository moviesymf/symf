<?php
namespace App\Service;
// namespace App\Controller;


class searchMovie  {


    // retourn film avec api omdb
    public static function search ($nomMovie) 
    {
        $descriptionMovie = NULL;
        $apiCle = 'rgfh'; 





        return $descriptionMovie;
    }


}

?>