<?php


namespace App\Controller;

use App\Entity\Movie;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request; 
use Symfony\Component\HttpFoundation\Response;
use App\Service\searchMovie;
use Doctrine\ORM\EntityManagerInterface;

class formMovie extends AbstractController
{

    /**
     * @Route("/", name="form")
     */


    public function create (Request $request, EntityManagerInterface $e): Response
    {


        $form = $this->createFormBuilder()
             ->add('nom', TextType::class)
             ->add('Score', IntegerType::class, [
                 'tab' => [
                'min' => 0,
                )

        ; 

        $form ->handleRequest($request);

        if($form->isSubmitted() && $form->isValid())
        {

            
            $data=$form->getData();
           
            $description = searchMovie::search($data['nom']);


            $movie = new Movie; 
            $movie->setNom($data['nom']);
            $movie->setDescription($description);
        
        }

        return $this->render('form.html.twig', [
            'formMovie' => $form->
        ]);
    }

}



?>