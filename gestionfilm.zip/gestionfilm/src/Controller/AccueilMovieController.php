<?php

namespace App\Controller;

use Doctrine\Persistence\ManagerRegistry;
use App\Entity\Movie;
use Symfony\Component\Routing\Annotation\Route;

class AccueilMovieController extends AbstractController
{
   /**
    * @Route("/", name="accueil")
    */

    public function show(ManagerRegistry $doctrine): Response
    {
        $movie = $doctrine->getRepository(Movie::class)->findBy([], ['nom' => 'ASC','score' => 'DESC']);

        return $this->render('base.html.twig', ['movies' => $movie]);
    }
    
}
